#include <iostream>
using namespace std;
class Node{
public:

int data;
Node* next;
Node(int data){
  this-> data = data;
  this-> next = NULL;
}
};
void print(Node* head){
  Node*temp = head;
  while(temp!=NULL){
    cout<<temp->data<< " ";
    temp = temp->next;
  }
};



bool checkforloop(Node* &head){
  if(head==NULL){
    return false;
  }
  Node* slow=head;
  Node* fast=head;

  while(fast != NULL){
    fast = fast->next;
    if(fast != NULL){
      fast = fast->next;
      slow = slow->next;
    }
    if(slow==fast){
      return true;
    }
  }
  return false;
}

int main() {
Node*head = new Node(10);
  Node*second = new Node(20);
  Node*third = new Node(30);
   Node*forth = new Node(200);
   Node*fifth = new Node(900);
   Node*sixth = new Node(60);
   Node*seven = new Node(10);
   Node*eight = new Node(20);
  head->next= second;
  second->next=third;
  third->next=forth;
  forth->next=fifth;
  fifth->next=sixth;
  sixth->next=seven;
  seven->next=eight;
  cout<<"printing"<<endl;
  print(head);
  bool findloop = checkforloop(head);
  if(findloop){
    cout<<"loop is present"<<endl;
  }
  else{
    cout<<"loop is not present"<<endl;
  };
    
  
  return 0;
  
  
}